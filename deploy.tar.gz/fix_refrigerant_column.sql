ALTER TABLE workshop_services RENAME COLUMN refrigerantpriceper100ml TO "refrigerantPricePer100ml";
