-- AlterTable
ALTER TABLE "vehicles" ADD COLUMN "summerTires" TEXT,
ADD COLUMN "winterTires" TEXT,
ADD COLUMN "allSeasonTires" TEXT;
