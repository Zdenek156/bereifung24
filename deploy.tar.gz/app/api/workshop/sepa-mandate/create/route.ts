// app/api/workshop/sepa-mandate/create/route.ts
// API Endpoint to create SEPA mandate using GoCardless Redirect Flow

import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import { createRedirectFlow } from '@/lib/gocardless'
import crypto from 'crypto'

export async function POST(request: Request) {
  try {
    const session = await getServerSession(authOptions)

    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Get workshop
    const workshop = await prisma.workshop.findUnique({
      where: { userId: session.user.id },
      select: {
        id: true,
        companyName: true,
        gocardlessCustomerId: true,
        gocardlessMandateId: true,
        gocardlessMandateStatus: true,
        user: {
          select: {
            email: true,
            firstName: true,
            lastName: true,
            street: true,
            city: true,
            zipCode: true
          }
        }
      }
    })

    if (!workshop) {
      return NextResponse.json({ error: 'Workshop not found' }, { status: 404 })
    }

    // Check if already has active mandate
    if (workshop.gocardlessMandateId && workshop.gocardlessMandateStatus === 'active') {
      return NextResponse.json(
        { error: 'Workshop already has an active SEPA mandate' },
        { status: 400 }
      )
    }

    // Generate session token
    const sessionToken = crypto.randomBytes(32).toString('hex')

    // Create redirect flow
    const successRedirectUrl = `${process.env.NEXTAUTH_URL}/dashboard/workshop/settings/sepa-mandate/complete`
    
    const redirectFlow = await createRedirectFlow({
      sessionToken,
      successRedirectUrl,
      description: `SEPA-Lastschriftmandat für ${workshop.companyName} - Bereifung24 Provisionsabzug`,
      prefillCustomer: {
        email: workshop.user.email,
        givenName: workshop.user.firstName,
        familyName: workshop.user.lastName,
        companyName: workshop.companyName
      }
    })

    // Store session token and redirect flow ID in database
    await prisma.workshop.update({
      where: { id: workshop.id },
      data: {
        gocardlessSessionToken: sessionToken,
        gocardlessRedirectFlowId: redirectFlow.id
      }
    })

    return NextResponse.json({
      success: true,
      redirectUrl: redirectFlow.redirect_url,
      redirectFlowId: redirectFlow.id,
      message: 'Bitte schließen Sie die SEPA-Mandatseinrichtung ab'
    })

  } catch (error: any) {
    console.error('Error creating SEPA mandate redirect flow:', error)
    return NextResponse.json(
      { error: error.message || 'Failed to create SEPA mandate' },
      { status: 500 }
    )
  }
}
