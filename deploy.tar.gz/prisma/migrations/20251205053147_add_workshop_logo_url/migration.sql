-- AlterTable
ALTER TABLE "workshops" ADD COLUMN "logoUrl" TEXT;
