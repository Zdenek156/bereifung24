-- AlterTable
ALTER TABLE "Vehicle" ADD COLUMN "vehicleType" TEXT NOT NULL DEFAULT 'CAR';
